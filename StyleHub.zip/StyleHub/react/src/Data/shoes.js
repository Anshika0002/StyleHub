export const mensShoesPage1=[
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-lehenga-choli/u/n/q/12-13-years-kids-begum-blue-piludi-original-imaghvhbqmjmybxu.jpeg?q=70&crop=false",
        "brand": "PILUDI",
        "title": "Girls Lehenga Choli Ethnic Wear",
        "color": "Pink",
        "selling_price": 4000,
        "price": 4000,
        "disscount": "2% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-lehenga-choli/m/4/a/13-14-years-diamond-dizvu-original-imagnz7phu5extnp.jpeg?q=70&crop=false",
        "brand": "PILUDI",
        "title": "Girls Lehenga Choli Ethnic Wear",
        "color": "Blue",
        "selling_price": 4000,
        "price": 4000,
        "disscount": "2% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-lehenga-choli/u/n/q/12-13-years-kids-begum-blue-piludi-original-imaghvhbqmjmybxu.jpeg?q=70&crop=false",
        "brand": "PILUDI",
        "title": "Girls Lehenga Choli Ethnic Wear",
        "color": "Pink",
        "selling_price": 4000,
        "price": 4000,
        "disscount": "2% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-lehenga-choli/u/n/q/12-13-years-kids-begum-blue-piludi-original-imaghvhbqmjmybxu.jpeg?q=70&crop=false",
        "brand": "PILUDI",
        "title": "Girls Lehenga Choli Ethnic Wear",
        "color": "Pink",
        "selling_price": 4000,
        "price": 4000,
        "disscount": "2% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-lehenga-choli/u/n/q/12-13-years-kids-begum-blue-piludi-original-imaghvhbqmjmybxu.jpeg?q=70&crop=false",
        "brand": "PILUDI",
        "title": "Girls Lehenga Choli Ethnic Wear",
        "color": "Pink",
        "selling_price": 4000,
        "price": 4000,
        "disscount": "2% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-lehenga-choli/u/n/q/12-13-years-kids-begum-blue-piludi-original-imaghvhbqmjmybxu.jpeg?q=70&crop=false",
        "brand": "PILUDI",
        "title": "Girls Lehenga Choli Ethnic Wear",
        "color": "Pink",
        "selling_price": 4000,
        "price": 4000,
        "disscount": "2% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-lehenga-choli/u/n/q/12-13-years-kids-begum-blue-piludi-original-imaghvhbqmjmybxu.jpeg?q=70&crop=false",
        "brand": "PILUDI",
        "title": "Girls Lehenga Choli Ethnic Wear",
        "color": "Pink",
        "selling_price": 4000,
        "price": 4000,
        "disscount": "2% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/kids-ethnic-set/8/o/j/7-8-years-7050-maroon-aj-dezines-original-imagj82gayf8w4gv.jpeg?q=70&crop=false",
        "brand": "AJ Designa",
        "title": "Boys Festive & Party Sherwani and Churidar Set",
        "color": "Maroon",
        "selling_price": 4000,       "price": 4000,
        "disscount": "80% off",
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Kids",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "dress"
    }
]